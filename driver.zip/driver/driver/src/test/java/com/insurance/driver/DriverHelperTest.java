package com.insurance.driver;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;

import com.insurance.driver.exception.ArgumentValidationException;
import com.insurance.driver.helper.DriverHelper;
import com.insurance.driver.model.InputData;

import static org.mockito.Mockito.when;

@RunWith(JUnit4.class)
public class DriverHelperTest {

	@Autowired
	DriverHelper driverHelper;
	
	@Rule
	public final ExpectedException exception = ExpectedException.none();
	
	@Test
	public void formatDateSuccess_Test() {
		Date date =driverHelper.formatDate("2020-11-11");
		Date parsedLocalDate=null;
		try {
			SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd");
			parsedLocalDate= formatter2.parse("2017-08-1 00:00:00.0 +0:00");
		}catch(Exception e) {
		e.printStackTrace();
		}
		assertEquals(date, parsedLocalDate);
	}
	
	@Test
	public void formatDateException_Test() {
		Date date =driverHelper.formatDate("xxx");
		
		exception.expect(Exception.class);
		exception.expectMessage("Invalid Date format");
	}
	
	@Test
	public void validateInputException_Test() {
			InputData inputData=new InputData("Tresa11","Francis",new Date());
			exception.expect(ArgumentValidationException.class);
			exception.expectMessage("Names can not contain numeric, Please check!");
			try{
			driverHelper.validateInput(inputData);
			}catch(ArgumentValidationException e) {
			assertEquals("Names can not contain numeric, Please check!",e.getMessage());
			}
	}


}