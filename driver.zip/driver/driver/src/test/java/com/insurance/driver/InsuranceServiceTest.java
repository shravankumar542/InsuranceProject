package com.insurance.driver;

import static org.mockito.Mockito.when;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.Test;

import static org.mockito.Mockito.doReturn;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.insurance.driver.helper.FileReadWriteUtil;
import com.insurance.driver.model.Driver;
import com.insurance.driver.model.InputData;
import com.insurance.driver.service.InsuranceService;


@RunWith(SpringRunner.class)
public class InsuranceServiceTest {
	
	@InjectMocks
	private InsuranceService insuranceService;
	
	@Mock
	private FileReadWriteUtil fileReaderWriter;
	
	@Value("${file.path}")
	String fileName;
	
	@Test
	public void getDriversByDateSuccess_Test() throws Exception{
		
		Date date1=new SimpleDateFormat("yyyy-MM-dd").parse("1994-03-04");
		Date date2=new SimpleDateFormat("yyyy-MM-dd").parse("2021-06-14");
		when(fileReaderWriter.readDataFromFile(fileName))
			.thenReturn(
					Arrays.asList(
							new Driver("82cbde7e-6f64-40f2-b1c7-07a3ced13dd5","Tresa","Francis",date1,date2),
							new Driver("2fc1784c-5571-4253-907e-216bc360d6ff","Chinna","challa",date1,date2)));  
		
		List<Driver> driversByDateCreated=insuranceService.getDriversByDate(date2);
		assertEquals(2,driversByDateCreated.size());
		assertEquals("82cbde7e-6f64-40f2-b1c7-07a3ced13dd5", (driversByDateCreated.get(0).getDriverID()));
		assertFalse(driversByDateCreated.isEmpty());
		
	}
	
	@Test
	public void getDrivers_Success_Test() throws Exception{
		
		Date date1=new SimpleDateFormat("yyyy-MM-dd").parse("1994-03-04");
		Date date2=new SimpleDateFormat("yyyy-MM-dd").parse("2021-06-14");
		when(fileReaderWriter.readDataFromFile(fileName))
			.thenReturn(
					Arrays.asList(
							new Driver("82cbde7e-6f64-40f2-b1c7-07a3ced13dd5","Tresa","Francis",date1,date2),
							new Driver("2fc1784c-5571-4253-907e-216bc360d6ff","Chinna","challa",date1,date2))); 
		
		List<Driver> driversByDateCreated=insuranceService.getDriver();
		assertEquals(2,driversByDateCreated.size());
		assertEquals("82cbde7e-6f64-40f2-b1c7-07a3ced13dd5", (driversByDateCreated.get(0).getDriverID()));
		assertFalse(driversByDateCreated.isEmpty());
		
	}

}
