package com.insurance.driver.exception;

public class ExceptionHandler extends IllegalArgumentException {
	
	public ExceptionHandler(String message) {
		super(message);
	}

}
