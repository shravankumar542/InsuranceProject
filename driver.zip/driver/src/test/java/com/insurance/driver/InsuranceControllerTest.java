package com.insurance.driver;



import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doReturn;
//import static org.mockito.Mockito.thenReturn;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;

import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.insurance.driver.controller.InsuranceController;
import com.insurance.driver.helper.DriverHelper;
import com.insurance.driver.service.InsuranceService;
import com.insurance.driver.model.Driver;
import com.insurance.driver.model.InputData;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.UUID;




@WebMvcTest(InsuranceController.class)
@RunWith(SpringRunner.class)
public class InsuranceControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private InsuranceService insuranceService;
	
	@MockBean
	private DriverHelper driverHelper;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	
	@Test
	public void driversGetAPI_Test() throws Exception {
		
		// we are mocking the business service and for that purpose we are using the mockBean and using the when interface of mockito.
		when(insuranceService.getDriver())
			.thenReturn(
					Arrays.asList(
							new Driver("82cbde7e-6f64-40f2-b1c7-07a3ced13dd5","Tresa","Francis",new Date(),new Date()),
							new Driver("2fc1784c-5571-4253-907e-216bc360d6ff","Chinna","challa",new Date(),new Date())
						));
		
		RequestBuilder request = MockMvcRequestBuilders
				.get("/drivers")
				.accept(MediaType.APPLICATION_JSON);
		
		
		MvcResult result= mockMvc
				.perform(request)
				.andExpect(status().isOk()) //checking for status here using matcher 
				.andReturn(); 
		
	}
	
	@Test
	public void driversCreateAPI_Test() throws Exception {
		
		// we are mocking the business service and for that purpose we are using the mockBean and using the when interface of mockito.
		Date date1=new SimpleDateFormat("yyyy-MM-dd").parse("1994-03-04");
		Date date2=new SimpleDateFormat("yyyy-MM-dd").parse("2021-06-14");
		when(insuranceService.save(new InputData("xxx","yyy",date1)))
			.thenReturn(
					new Driver(UUID.randomUUID().toString(),"xxx","yyy",date1,date2));
		
		RequestBuilder request = MockMvcRequestBuilders
				.post("/drivers/create")
				.content(objectMapper.writeValueAsString(new InputData("xxx","yyy",date1)))
				.accept(MediaType.APPLICATION_JSON);
		
		
		MvcResult result= mockMvc
				.perform(request)
				.andExpect(status().isOk()) //checking for status here using matcher 
				.andExpect(content().string("Record is inserted"))
				.andReturn(); 
		
	}
	
	@Test
	public void driversCreateAPI_InvalidArgument_Test() throws Exception {		
		RequestBuilder request = MockMvcRequestBuilders
				.post("/drivers/create")
				.content(objectMapper.writeValueAsString(new InputData("","yyy",new Date())))
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result= mockMvc
				.perform(request)
				.andExpect(status().is(415))//checking for status here using matcher 
				.andReturn();		
	}
	
	@Test
	public void driversCreateAPI_RecordNotFoundException_Test() throws Exception {		
		RequestBuilder request = MockMvcRequestBuilders
				.post("/drivers/create")
				.content(objectMapper.writeValueAsString(new InputData(null,"yyy",new Date())))
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result= mockMvc
				.perform(request)
				.andExpect(status().is4xxClientError())
				//.andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Validation Failed"))//checking for status here using matcher 
				.andReturn();		
	}
	
	@Test
	public void driverByDateAPI_Test() throws Exception {
		
		// we are mocking the business service and for that purpose we are using the mockBean and using the when interface of mockito.
		when(insuranceService.getDriver())
			.thenReturn(
					Arrays.asList(
							new Driver("82cbde7e-6f64-40f2-b1c7-07a3ced13dd5","Tresa","Francis",new Date(),new Date()),
							new Driver("2fc1784c-5571-4253-907e-216bc360d6ff","Chinna","challa",new Date(),new Date())
						));
		
		RequestBuilder request = MockMvcRequestBuilders
				.get("/drivers/byDate")
				.param("date", "2021-06-14")
				.accept(MediaType.APPLICATION_JSON);
		
		
		MvcResult result= mockMvc
				.perform(request)
				.andExpect(status().isOk())
				.andReturn(); 
		
	}
	
	@Test
	public void driverByDateAPIWithInvalidDate_Test() throws Exception {
		
		// we are mocking the business service and for that purpose we are using the mockBean and using the when interface of mockito.
		when(insuranceService.getDriver())
			.thenReturn(
					Arrays.asList(
							new Driver("82cbde7e-6f64-40f2-b1c7-07a3ced13dd5","Tresa","Francis",new Date(),new Date()),
							new Driver("2fc1784c-5571-4253-907e-216bc360d6ff","Chinna","challa",new Date(),new Date())
						));
		
		RequestBuilder request = MockMvcRequestBuilders
				.get("/drivers/byDate")
				.param("date", "")
				.accept(MediaType.APPLICATION_JSON);
		
		
		MvcResult result= mockMvc
				.perform(request)
				.andExpect(status().isBadRequest())
				.andReturn(); 
		
	}
	
}