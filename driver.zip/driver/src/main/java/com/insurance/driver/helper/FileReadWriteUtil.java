package com.insurance.driver.helper;

import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormatter;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.insurance.driver.exception.ArgumentValidationException;
import com.insurance.driver.model.Driver;

@Component
public class FileReadWriteUtil {
	
	
	public void WriteDataToFile(String fileName,Driver driver) throws IOException, InvalidFormatException{
	
        FileInputStream inputStream = new FileInputStream(new File(fileName));
        Workbook workbook = WorkbookFactory.create(inputStream);

        Sheet sheet = workbook.getSheetAt(0);
        int rowCount = sheet.getLastRowNum();
 
        Row row = sheet.createRow(++rowCount);
        //int columnCount = 5;
        Cell cell = row.createCell(0);
        cell.setCellValue(driver.getDriverID());
        
        cell = row.createCell(1);
        cell.setCellValue(driver.getFirstName());
     
        cell = row.createCell(2);
        cell.setCellValue(driver.getLastName());
     
        cell = row.createCell(3);
        CellStyle cellStyle = workbook.createCellStyle();
        CreationHelper creationHelper = workbook.getCreationHelper();
        cellStyle.setDataFormat(creationHelper.createDataFormat().getFormat("yyyy-MM-dd"));
        cell.setCellStyle(cellStyle);

        cell.setCellValue(driver.getDate_of_birth());
        
        cell = row.createCell(4);
        cell.setCellStyle(cellStyle);
        cell.setCellValue(driver.getCreationDate());
        
        FileOutputStream outputStream = new FileOutputStream(fileName);
        workbook.write(outputStream);
        outputStream.close();

	}
	public List<Driver> readDataFromFile(String fileName) throws IOException, ArgumentValidationException{
		
		List<Driver> drivers= new ArrayList<Driver>();
		FileInputStream inputStream = new FileInputStream(new File(fileName));
		Workbook workbook = new XSSFWorkbook(inputStream);
		Sheet firstSheet = workbook.getSheetAt(0);
		Iterator<Row> iterator = firstSheet.iterator();
		while (iterator.hasNext()) {
			Row nextRow = iterator.next();
			Driver driver=new Driver();
			driver.setDriverID(nextRow.getCell(0).getStringCellValue());
			driver.setFirstName(nextRow.getCell(1).getStringCellValue());
			driver.setLastName(nextRow.getCell(2).getStringCellValue());
			driver.setDate_of_birth(nextRow.getCell(3).getDateCellValue());
			driver.setCreationDate(nextRow.getCell(4).getDateCellValue());
			
			drivers.add(driver);
		}
		inputStream.close();
		return drivers;
	}
	
	private Date dateFormatter(Date date) throws ArgumentValidationException {
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");          
		String inActiveDate = null;
		
		try {

		    inActiveDate = format1.format(date);
		    System.out.println(inActiveDate);
		    date = format1.parse(inActiveDate);
		    System.out.println("date formatter::"+date);
		    
		} catch (ParseException e1) {
		    // TODO Auto-generated catch block
		    e1.printStackTrace();
		    throw new ArgumentValidationException("unable to parse date");
		    

		} 
		return date;
	}

}
