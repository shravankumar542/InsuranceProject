package com.insurance.driver.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.driver.exception.ArgumentValidationException;

import com.insurance.driver.helper.DriverHelper;
import com.insurance.driver.model.Driver;
import com.insurance.driver.model.InputData;

import com.insurance.driver.service.InsuranceService;

@RestController
@RequestMapping(path = "/drivers", produces=MediaType.APPLICATION_JSON_VALUE)
public class InsuranceController {
	
	@Autowired DriverHelper driverHelper;
	@Autowired InsuranceService insuranceService;
	@GetMapping
	public List<Driver>  drivers() {
		try {
			
			return insuranceService.getDriver();
		} catch (Exception e) {
            return null;
		}
		//return "hello world with get Mappings";
	}
	
	@GetMapping(path="/byDate")
	public List<Driver> driverByDate(@RequestParam String date
			) throws IOException, ArgumentValidationException {
		
		Date inputDate=driverHelper.formatDate(date);
		return insuranceService.getDriversByDate(inputDate);
		//return "";
	}
	
	@PostMapping(path="/create")
	public ResponseEntity<String> diverCreate(@Valid @RequestBody InputData inputData) throws InvalidFormatException, ArgumentValidationException, IOException{
		try {
				
				driverHelper.validateInput(inputData);
				Driver driver=insuranceService.save(inputData);
				return ResponseEntity.status(HttpStatus.CREATED).body("Record is inserted");
        } catch (Exception e) {
        				System.out.println(e);
                        return ResponseEntity.status(HttpStatus.UNPROCESSABLE_ENTITY).body(e.getMessage());
        }
	}
	
}
