package com.insurance.driver.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.UUID;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;  


public class Driver implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String driverID;
	@NotBlank
	@NotEmpty
	private String firstName;
	@NotBlank
	@NotEmpty
	private String lastName;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date date_of_birth;
	@JsonFormat(pattern="yyyy-MM-dd")
	private Date creationDate;
	
	
	
	public Driver(String driverID, @NotBlank @NotEmpty String firstName, @NotBlank @NotEmpty String lastName,
			Date date_of_birth, Date creationDate) {
		super();
		this.driverID = driverID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.date_of_birth = date_of_birth;
		this.creationDate = creationDate;
	}
	public Driver() {
		// TODO Auto-generated constructor stub
	}
	public String getDriverID() {
		return driverID;
	}
	public void setDriverID(String driverID) {
		this.driverID = driverID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	@Override
	public String toString() {
		return "Driver [id=" + driverID + ", firstName=" + firstName + ", lastName=" + lastName + 
				", date_of_birth=" + date_of_birth + ", creationDate="
				+ creationDate + "]";
	}
	

}
