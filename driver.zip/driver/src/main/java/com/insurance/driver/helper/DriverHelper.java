package com.insurance.driver.helper;


import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.stereotype.Component;
import com.insurance.driver.exception.ArgumentValidationException;
import com.insurance.driver.exception.ExceptionHandler;
import com.insurance.driver.model.InputData;


@Component
public class DriverHelper {
	
	
	public Date formatDate(String date) throws ExceptionHandler{
		try {
			Date date1=new SimpleDateFormat("yyyy-MM-dd").parse(date);
			return date1;
		}catch(Exception e) {
			throw new ExceptionHandler("Invalid Date format");
		}
		//SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-DD");
	}
	
	
	
    public void validateInput(InputData inputData) throws ArgumentValidationException{
        String pattern = ".*\\d.*";
        
        //|| inputData.getDob().isPresent()
        if(inputData.getFirstName().isEmpty() || inputData.getLastName().isEmpty()) {
        	System.out.println("first name empty check"+inputData.getFirstName()+" last name::"+inputData.getLastName());
                        throw new ArgumentValidationException("Input can not be null, Please check!");
        } else if(inputData.getFirstName().matches(pattern) || inputData.getLastName().matches(pattern)) {
        	System.out.println("pattern check");
                        throw new ArgumentValidationException("Names can not contain numeric, Please check!");
        }
        
        System.out.println("return from the validateInput");
}

}
