package com.insurance.driver.model;

import java.time.LocalDate;

import javax.validation.constraints.NotEmpty;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class Requestmapper {
	
	@NotEmpty
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private LocalDate date;

}
