package com.insurance.driver.service;


import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.insurance.driver.exception.ArgumentValidationException;
import com.insurance.driver.helper.DriverHelper;
import com.insurance.driver.helper.FileReadWriteUtil;
import com.insurance.driver.model.Driver;
import com.insurance.driver.model.InputData;


@Service
public class InsuranceService {
	
	@Autowired
	DriverHelper driverHelper;
	
	@Autowired
	FileReadWriteUtil fileReadWriter;
	
	@Value("${file.path}")
	String fileName;
	public Driver save(InputData inputData) throws ArgumentValidationException,IOException, InvalidFormatException{
				
		System.out.println("validate input passed");

		Driver driver=new Driver();
		
		driver.setDriverID(UUID.randomUUID().toString());
		driver.setDate_of_birth(inputData.getDate_of_birth());
		driver.setFirstName(inputData.getFirstName());
		driver.setLastName(inputData.getLastName());
		driver.setCreationDate(new Date());
		System.out.println("before saving to file");
		//String filePath="src/main/resources/driversNew.xlsx";
		fileReadWriter.WriteDataToFile(fileName,driver);
		
		return driver;
		
	}
	
	public List<Driver> getDriversByDate(Date inputDate) throws IOException, ArgumentValidationException {
		
		/* Fetch all the driver Details from the File */
		List<Driver> driversFromFile= fileReadWriter.readDataFromFile(fileName);
		System.out.println("inputDate::"+inputDate);
		/* Test loggers to see whats the drivers values 
		 * driversFromFile.stream().map(d-> d.getCreationDate()).sorted().forEach(System.out::println);
		 * driversFromFile.stream().filter(d -> d.getCreationDate().equals(inputDate))
							.map(d-> d.getCreationDate()).sorted().forEach(System.out::println); */
		
		/* Filter values which matches with the date passed */	
		List<Driver> driversListMatchInputDate =driversFromFile.stream()
													.filter(d -> d.getCreationDate().equals(inputDate))
													.collect(Collectors.toList());
		System.out.println("driversListMAtch::"+driversListMatchInputDate.size()+" drivers size::"+driversFromFile.size());
		return driversListMatchInputDate;
	}
	
		
	public List<Driver> getDriver() throws IOException, ArgumentValidationException{
		System.out.println("inside getDriver");
		return fileReadWriter.readDataFromFile(fileName);
	}
	
	
	
}
