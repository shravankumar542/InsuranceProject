package com.insurance.driver.model;


import java.util.Date;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Past;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;


@AllArgsConstructor
public class InputData {
                
                @NotEmpty(message = "First Name cannot be empty")
                @NotBlank(message = "First Name cannot be Blank")
                private String firstName;
                @NotEmpty(message = "Last Name cannot be empty")
                @NotBlank(message = "Last Name cannot be Blank")
                private String lastName;
                
                @Past(message = "date of birth should be a past date")
                @JsonFormat(pattern = "yyyy-MM-dd")
                //@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
                private Date date_of_birth;
                
				public String getFirstName() {
                                return firstName;
                }
                public void setFirstName(@NotEmpty String firstName) {
                                this.firstName = firstName;
                }
                public String getLastName() {
                                return lastName;
                }
                public void setLastName(String lastName) {
                                this.lastName = lastName;
                }
                
                public Date getDate_of_birth() {
					return date_of_birth;
				}
				public void setDate_of_birth(Date date_of_birth) {
					this.date_of_birth = date_of_birth;
				}
				
				public InputData(
						@NotEmpty(message = "First Name cannot be empty") @NotBlank(message = "First Name cannot be Blank") String firstName,
						@NotEmpty(message = "Last Name cannot be empty") @NotBlank(message = "Last Name cannot be Blank") String lastName,
						@Past(message = "date of birth should be a past date") Date date_of_birth) {
					super();
					this.firstName = firstName;
					this.lastName = lastName;
					this.date_of_birth = date_of_birth;
				}
				public InputData() {
					super();
				}
				
                
}

